import requests
import re
import time

headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 QIHU 360EE'
}

def getHtmlList(pageindex):
    """获取一个页面下所有的目标网址"""
pagecount = 2053
currentpage = 1
itemcount = 0
All_re_html_list = []
while currentpage <= 11:
    time.sleep(0.01)
    currentpage += 1
    response_index = requests.get('https://ifworlddesignguide.com/api/v2/articles/collections/394?cursor='
                                + str(itemcount)
                                + '&lang=en&count=200'
                                + '&orderby=date&filter=%7B%22filters%22:[]%7D',headers = headers)
    html_index = response_index.text
    All_re_html_list += re.findall('"id":.*?,"type":".*?","headline":".*?","subline":.*?,"label":.*?,"href":"(.*?)","description":".*?"', html_index)
    if itemcount + 200 <= 2053:
        itemcount += 200
    else:
        itemcount = 2053
    print(html_index)
    print(currentpage)
else:
    for index in range(len(All_re_html_list)):
        All_re_html_list[index] = All_re_html_list[index].replace('\\', '')
    print(All_re_html_list)
    print(len(All_re_html_list))

# print(html_index.data[0].href)

