'''生成PPT'''
import os
import openpyxl

"""导入自己写的一个库，存放所有图片及文本目录"""
import AllDirNames

"""导入PPT库"""
from pptx import Presentation
from pptx.util import Inches
from PIL import Image #图片库

#基本参数准备
img_foldernames = AllDirNames.breaklist_AllDirNames
img_dirs = []
img_files_path = []

folderindex = 0

#新建一个空白PPT
prs = Presentation()

#获取每个文件夹路径字符
for img_foldername in img_foldernames:
    img_dirs.append('../imgs/' + str(img_foldername))

#从每个文件夹路径中获取每个图片
for img_dir in img_dirs:

    # 查找该路径下所有图片文件（包含文件格式后缀）
    for root, dirs, files in os.walk(img_dir):
        wb = openpyxl.load_workbook('../'+ img_foldernames[folderindex] + '.xlsx')
        sheet = wb.worksheets[0]

        #幻灯片备注表格文件
        celltexts = ''
        #获取表格所有文本信息
        for row in sheet.iter_rows():
            cell_col_index = 0
            for cell in row:
                cell_col_index += 1
                if cell.value:
                    if cell_col_index >= 2:
                        celltexts = celltexts + "	:" + str(cell.value)
                    else:
                        celltexts = celltexts + str(cell.value)
            celltexts = celltexts + '\n'

        for file in files:
            img_files_path.append('../imgs/' + str(img_dir) + '/' + str(file))


        img_index = 1
        #添加照片
        for img_path in img_files_path:
            blank_slide_layout = prs.slide_layouts[6]  # 选用空白版式
            slide = prs.slides.add_slide(blank_slide_layout)  # 创建新幻灯片页

            if img_index <= 1:
                # 添加幻灯片备注
                notes_slide = slide.notes_slide
                text_frame = notes_slide.notes_text_frame
                text_frame.text = str(celltexts)

            #获取该图片尺寸
            img_read = Image.open(img_path)
            img_w = img_read.width
            img_h = img_read.height
            left = top = Inches(0)

            #自适应等比缩放图片至优化大小
            if img_w > img_h:
                img_size_align = img_w
                pic = slide.shapes.add_picture(img_path, left, top,width=Inches(16))
            else:
                img_size_align = img_h
                pic = slide.shapes.add_picture(img_path, left, top,height=Inches(9))

        img_files_path = []

    folderindex += 1
    print(str(folderindex) + ' Folder Finished.')

    #每生成400张幻灯片停一下，缓冲
    if folderindex > 400:
        break

#保存该PPT文件（向磁盘写入PPT文件）
prs.save('IF product design awards.pptx')