"""请求网页"""

"""导入请求网页库"""
import requests
import re

"""导入Excel库"""
from openpyxl import Workbook

import time
import parsel
import os

"""导入自己写的两个库，一个存放所有要爬的网址，一个用于存储爬取进度"""
import AllIFUrlList
import manualbreakpoint_url

#请求头文件，仿照浏览器访问的方式
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 QIHU 360EE'
}

#如果有手动覆盖控制，则执行
if manualbreakpoint_url:
    all_IF_Url = manualbreakpoint_url.Manualurl_list
    print('Enable manual urls override.')
    Itemindex = len(AllIFUrlList.AllexistUrl_list) - len(manualbreakpoint_url.Manualurl_list) + 1
    print('Itemindex begin at ' + str(Itemindex) + '.')
else:
    all_IF_Url = AllIFUrlList.AllexistUrl_list
    Itemindex = 1

# all_IF_Url = AllIFUrlList.AllexistUrl_list
# Itemindex = 1

#选取地址池中的地址，逐个执行
for IF_Url in all_IF_Url:
    print(IF_Url)
    response = requests.get(IF_Url, headers=headers)
    html = response.text
    # print(html)

    """解析网页"""
    #解析作品图片
    urls = re.findall('<img data-src="(.*?)" alt=".*?" width=".*?" height=".*?">', html)  #正则表达式

    selector = parsel.Selector(html)

    """保存图片"""
    #根据产品名称创建目录
    no_char_list = ['*', '|', ':', '?', '/', '<', '>', '"', '\\'] # 非法字符合集

    dir_name =str(Itemindex) + '_' + '_'.join(re.findall(r'<span class="product-name" itemprop="name">(.*?)</span>', html)
                        + re.findall('<span itemprop="alternateName">(.*?)</span>', html))  #此处用到列表拼接+列表中所有元素合并成一个字符串
    #删掉非法字符
    for char in no_char_list:
        if char in dir_name:
            dir_name = dir_name.replace(char, '')

    #目录不存在，则创建
    if not os.path.exists(dir_name):
        os.mkdir(dir_name)
    print(dir_name)

    #如果文件不存在，则写入文件
    Img_index = 1
    for url in urls:
        time.sleep(0.01) #对于较差的服务器，需要加入一个0.01秒的延迟访问，否则对方服务器可能爬崩
        file_name = url.split('/')[-1]
        if not os.path.exists(dir_name + '/' + file_name):
            try:
                response = requests.get(url, headers=headers)
                with open(dir_name + '/' + file_name, 'wb')as f:
                    f.write(response.content)
            except Exception:
                pass
        print('Picture ' + str(Img_index) + ' downloaded.')
        Img_index += 1

    #分析当前产品的表单信息
    wbname = dir_name
    wb = Workbook()
    ws = wb.active
    wbtext_list = selector.xpath('//div[@class="profile-text-box-wrapper"]/ul/li/span/text()').getall()
    wbdesigntext_list = selector.xpath('//div[6]/div[2]/div/p/text()').getall()
    wbstatementtext_list = selector.xpath('/html/body/main/div/div[3]/div/p/text()').getall()
    print(wbstatementtext_list[0].strip())

    # print(wbdesigntext_list[0:1][0].strip())
    # print(wbtext_list)
    # print(wbtext_list[0:1][0],wbtext_list[1:2][0])

    #向Excel表格填入信息
    ws.append([IF_Url])
    ws.append(['title', wbname])
    ws.append(['————————'])
    ws.append(['Statement', wbstatementtext_list[0].strip()])
    ws.append([wbdesigntext_list[0:1][0].strip()])
    ws.append([wbdesigntext_list[1:2][0].strip()])
    ws.append(['————————'])
    ws.append([wbtext_list[0:1][0], wbtext_list[1:2][0]]) #列表嵌套列表的提取方式，提取第一个列表的第一个元素
    ws.append([wbtext_list[2:3][0], wbtext_list[3:4][0]])
    ws.append([wbtext_list[4:5][0], wbtext_list[5:6][0]])
    ws.append([wbtext_list[6:7][0], wbtext_list[7:8][0]])

    wb.save(wbname + '.xlsx') #保存该Excel表格文件
    Itemindex += 1